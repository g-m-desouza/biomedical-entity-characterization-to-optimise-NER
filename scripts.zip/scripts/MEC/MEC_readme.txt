README — BioNE_CA.ipynb
==========================

PURPOSE
-------
This notebook implements the primary BioNE CA linguistic characterisation used
to compare Company Name and Line of Therapy (LoT) entities in the ODAN training
data. Only the initial annotation training data is used so that the
characterisation does not use validation or test data.

ROLE IN THE WORKFLOW
--------------------
1. Load the unrefined ODAN training data.
2. Shuffle the data using random_state=42.
3. Split records by source.
4. Construct a fixed 100-record systematic sample:
   - 83 FDA records
   - 17 BusinessWire/non-FDA records
5. Characterise Company Name and LoT using several independent linguistic
   dimensions.
6. Produce descriptive tables and plots for interpretation.

INPUTS
------
The notebook currently expects:

1. Unrefined training spreadsheet
   Original hard-coded path:
   ..\..\..\..\modules\CSCK700 Computer Science Capstone Project\
   week17 to 28\Data\data_complete\un_refined\datasets\unrefinedTrain.xlsx

2. Saved BioNE CA sample
   Relative path:
   BioNE CA data/BioNE CA data.csv

Expected fields used by the analysis include:
- source
- text
- company
- LoT

The local paths above should be changed to match the directory structure of the
archived/released data.

IMPORTANT INPUT NOTE
--------------------
The notebook first generates the 100-record sample as df_unrefinedSample, but
the cell that saves this sample is commented out. The downstream analysis then
loads the existing file "BioNE CA data/BioNE CA data.csv" into df_BioNE_CA.

For a completely clean rerun, either:
- ensure BioNE CA data.csv is the saved version of the generated 100-record
  sample; or
- amend the notebook so the downstream analysis uses df_unrefinedSample
  directly.

DEPENDENCIES
------------
Python 3 with:
- pandas
- numpy
- matplotlib
- seaborn
- scikit-learn
- spaCy
- regex
- nltk

spaCy model required:
- en_core_web_trf

Example installation commands:
    pip install pandas numpy matplotlib seaborn scikit-learn spacy regex nltk
    python -m spacy download en_core_web_trf

MAIN ANALYSES
-------------
The notebook evaluates Company Name and LoT using:

- Entity length
  Alphabetic word counts are calculated for each entity.

- Surface-form repetition
  Entity strings are normalised for case and whitespace, and the proportions
  of unique and repeated surface forms are calculated.

- Common-word frequencies
  Alphabetic non-stopword tokens are counted and normalised per 1,000 eligible
  tokens.

- Isolated n-grams
  Bigram, trigram and 4-gram frequencies are calculated within entity
  components and normalised per 1,000 possible n-grams.

- Contextual lexical consistency
  Up to five whitespace-delimited tokens before and after each entity are
  extracted. Entity tokens are excluded. Common words and contextual 2-, 3-
  and 4-grams are then evaluated.

- Part-of-speech characteristics
  POS composition and the number of unique POS categories are compared.

- Corrected Type-Token Ratio (CTTR)
  Contextual lexical diversity is calculated record-wise as:
      CTTR = V / sqrt(2N)
  where V is the number of unique alphabetic word types and N is the total
  number of alphabetic word tokens.

ANNOTATION HANDLING
-------------------
The artificial uppercase "AND" separator is treated as an annotation separator
for multiple/discontinuous components, not as a linguistic word. Components
are therefore processed separately where appropriate.

SAMPLING
--------
Fixed-size systematic sampling uses approximately equally spaced row positions
after shuffling. The sampling interval is population_size / sample_size and the
selected positions are floor(k * interval).

Random seed:
- 42 for the initial shuffle

OUTPUTS
-------
The notebook primarily displays:
- descriptive statistics
- pandas tables
- boxplots/bar plots for the BioNE CA dimensions

The sample-save line is present but commented out:
    # df_unrefinedSample.to_csv('BioNE CA data.csv')

No final analysis tables are automatically written to disk by the current
version of this notebook.

HOW TO RUN
----------
1. Create/activate a Python environment with the dependencies above.
2. Install the spaCy en_core_web_trf model.
3. Update the input paths.
4. Ensure BioNE CA data/BioNE CA data.csv exists, or modify the notebook to use
   the newly generated df_unrefinedSample.
5. Run cells from top to bottom.

REPRODUCIBILITY NOTES
---------------------
- The initial shuffle is reproducible because random_state=42 is fixed.
- The notebook assumes the source labels distinguish FDA from non-FDA records.
- Several paths reflect the original local project directory and must be
  changed before reuse on another system.
- Package versions are not pinned in the notebook.
- BioNE CA is implemented as a multidimensional characterisation: the measures
  are interpreted independently rather than being combined into one aggregate
  complexity score.
