README - MEC_sensitivity_independent_sampling.ipynb
===========================================================

PURPOSE
-------
This notebook repeats the BioNE CA characterisation on an independent
100-record sensitivity sample. Records used in the original BioNE CA sample are
excluded before the new sample is drawn.

ROLE IN THE WORKFLOW
--------------------
This notebook is the data-generation stage for the sensitivity analysis. Its
CSV outputs are consumed by sensitivity_analysis_aligned(1).ipynb.

The workflow is:
1. Load the initial unrefined annotation training corpus.
2. Load the original 100-record BioNE CA sample.
3. Build a normalised source + full-text record key.
4. Exclude all records contained in the original BioNE CA sample.
5. Verify that the exclusion succeeded.
6. Split the remaining data into FDA and BusinessWire/non-FDA strata.
7. Shuffle each stratum using random_state=42.
8. Apply fixed-size systematic sampling:
   - 83 FDA records
   - 17 BusinessWire/non-FDA records
9. Verify that the final sensitivity sample contains 100 records and has zero
   overlap with the original BioNE CA sample.
10. Recalculate the BioNE CA linguistic measures.
11. Export the derived sensitivity-analysis files.

INPUTS
------
1. Unrefined training spreadsheet
   Original hard-coded path:
   ..\..\..\..\..\modules\CSCK700 Computer Science Capstone Project\
   week17 to 28\Data\data_complete\un_refined\datasets\unrefinedTrain.xlsx

2. Original BioNE CA sample
   Relative path:
   ../BioNE CA data/BioNE CA data.csv

Expected fields include:
- source
- text
- company
- LoT

The paths should be updated to match the released data-package structure.

DEPENDENCIES
------------
Python 3 with:
- pandas
- numpy
- matplotlib
- seaborn
- scikit-learn
- spaCy
- regex
- nltk

spaCy model required:
- en_core_web_trf

Example installation commands:
    pip install pandas numpy matplotlib seaborn scikit-learn spacy regex nltk
    python -m spacy download en_core_web_trf

INDEPENDENT-SAMPLE QC
---------------------
Record matching is based on:
- lower-cased/trimmed source; plus
- normalised full record text.

The notebook asserts that:
- every original BioNE CA record can be found in the unrefined training data;
- all original BioNE CA records have been removed before resampling;
- the final sample contains exactly 83 FDA + 17 non-FDA records; and
- overlap between the original and sensitivity samples is zero.

Random seed:
- 42 for shuffling each source stratum

MAIN MEASURES
-------------
The independent sample is processed using the same main dimensions as the
primary BioNE CA notebook:

- entity length
- unique/repeated surface-form proportions
- isolated common-word frequencies
- isolated bigram, trigram and 4-gram frequencies
- contextual common-word frequencies
- contextual bigram, trigram and 4-gram frequencies
- POS characteristics and unique POS-category counts
- record-level CTTR

Frequencies are normalised where appropriate, including per 1,000 tokens or
per 1,000 possible n-grams.

The artificial uppercase "AND" annotation separator is handled as a separator
between components rather than as a linguistic token.

CONTEXT WINDOW
--------------
For contextual lexical consistency, the notebook uses up to five
whitespace-delimited tokens immediately before and after an annotated entity.
The entity itself is excluded. Components separated by artificial "AND" are
located independently, overlapping windows are de-duplicated, and entity
component tokens are removed before contextual frequency analysis.

OUTPUT DIRECTORY
----------------
The notebook writes files to:
    sensitivity analysis data/

This directory must already exist in the current version of the notebook.

MAIN OUTPUT FILES
-----------------
Sample:
- sensitivity_sample.csv

Entity structure:
- company_length_sensitivity_analysis.csv
- lot_length_sensitivity_analysis.csv
- surface_form_sensitivity_analysis.csv
- company_unique_pos_length_sensitivity_analysis.csv
- lot_unique_pos_length_sensitivity_analysis.csv
- cttr_sensitivity_analysis.csv

Isolated lexical measures:
- company_words_for_sensitivity_analysis.csv
- lot_words_for_sensitivity_analysis.csv
- company_bi_sensitivity_analysis.csv
- lot_bi_sensitivity_analysis.csv
- company_tri_sensitivity_analysis.csv
- lot_tri_sensitivity_analysis.csv
- company_four_sensitivity_analysis.csv
- lot_four_sensitivity_analysis.csv

Contextual lexical measures:
- company_context_words_sensitivity_analysis.csv
- lot_context_words_sensitivity_analysis.csv
- company_context_bi_sensitivity_analysis.csv
- lot_context_bi_sensitivity_analysis.csv
- company_context_tri_sensitivity_analysis.csv
- lot_context_tri_sensitivity_analysis.csv
- company_context_four_sensitivity_analysis.csv
- lot_context_four_sensitivity_analysis.csv

Plotting/merged n-gram tables are also exported:
- bigram_comparison_sensitivity_analysis.csv
- trigram_comparison_sensitivity_analysis.csv
- fourgram_comparison_sensitivity_analysis.csv

HOW TO RUN
----------
1. Install the required Python packages and spaCy model.
2. Update both input paths.
3. Create the folder "sensitivity analysis data" if it does not exist.
4. Run all cells from top to bottom.
5. Confirm that the QC assertions pass.
6. Use the exported files as inputs to sensitivity_analysis_aligned(1).ipynb.

REPRODUCIBILITY NOTES
---------------------
- The independent sampling procedure is deterministic given the same input data
  because the shuffle seed is fixed.
- Only the training corpus is used in this sensitivity-sample construction.
- Package versions are not pinned.
- Original local Windows-style paths remain in the notebook and should be
  replaced for a portable release.
