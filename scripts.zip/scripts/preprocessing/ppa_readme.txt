README — PPA(4).ipynb
======================

PURPOSE
-------
This notebook performs preprocessing/preparation analysis on the Oncology Drug
Approval News (ODAN) data and converts the annotated CoNLL-style data into CSV
files suitable for the downstream DistilBERT and BioDistilBERT token-
classification notebooks.

It contains both exploratory preprocessing analysis and the final data-
preparation steps.

ROLE IN THE WORKFLOW
--------------------
1. Load refined and unrefined tabulated training datasets.
2. Load corresponding CoNLL annotation files.
3. Examine dataset characteristics, including:
   - token distribution per record
   - Company Name and LoT counts
   - entity/token class balance
   - word and sentence counts
   - common words and phrases
   - stop words
   - non-word/symbol tokens
4. Identify symbols for conservative removal.
5. Preserve symbols that are part of annotated named entities or common
   punctuation retained by the preprocessing logic.
6. Remove selected symbols from CoNLL train/validation/test data.
7. Add numeric BIO tag IDs.
8. Verify record/token lengths.
9. Convert CoNLL records into grouped CSV datasets for model training.
10. Create a refined training dataset with the additional training data merged
    when required.

MAIN INPUTS
-----------
The notebook uses original local paths under:
    ..\..\..\week17 to 28\Data\...

Principal source files include:
- refinedTrain.xlsx
- unrefinedTrain.xlsx
- refined_taggedtrain.conll
- refined_taggedtrain_add.conll
- refined_taggedval.conll
- refined_taggedtest.conll
- unrefined_taggedtrain.conll
- unrefined_taggedval.conll
- unrefined_taggedtest.conll

It also reads/writes intermediate PPA analysis files, including the symbol-count
spreadsheet used during symbol-removal preparation.

All paths should be updated to match the released project directory.

DEPENDENCIES
------------
Python 3 with:
- pandas
- numpy
- spaCy
- matplotlib
- nltk
- datasets

spaCy model required:
- en_core_web_trf

Example installation commands:
    pip install pandas numpy spacy matplotlib nltk datasets
    python -m spacy download en_core_web_trf

BIO LABEL MAPPING
-----------------
The notebook uses:
- O     = 0
- B-Co  = 1
- I-Co  = 2
- B-LoT = 3
- I-LoT = 4

SYMBOL PREPROCESSING
--------------------
Symbols are examined using the training data. Symbols that occur within Company
Name or LoT annotations are protected by the selection logic. The notebook also
retains selected common punctuation and applies an additional explicit set of
symbols for removal.

Tokens containing digits are returned without Unicode normalisation by
normalise_token(); other tokens are NFC-normalised.

The processed CoNLL files contain:
    token BIO_tag numeric_tag_id

PREPARED MODEL-DATA FORMAT
--------------------------
The read_conll() function groups each record/sentence into list-valued columns.

The resulting CSV files include:
- sentence num
- token
- ner_tag
- ner_tag_ids
- token_len
- ner_tag_len
- ner_tag_ids_len
- matched

These files are then consumed by the BERT notebooks, which retain:
- sentence num
- token
- ner_tag_ids

MAIN OUTPUTS
------------
Processed CoNLL files:
- refined_taggedtrain_symbolsremoved.conll
- refined_taggedtrain_add_symbolsremoved.conll
- refined_taggedval_symbolsremoved.conll
- refined_taggedtest_symbolsremoved.conll
- unrefined_taggedtrain_symbolsremoved.conll
- unrefined_taggedval_symbolsremoved.conll
- unrefined_taggedtest_symbolsremoved.conll

Prepared CSV files:
- refined_train.csv
- refined_val.csv
- refined_test.csv
- refined_add_train.csv
- unrefined_train.csv
- unrefined_val.csv
- unrefined_test.csv

The notebook also writes exploratory PPA files for:
- Company/LoT word counts
- stop-word counts
- symbol counts
- phrase counts

HOW TO RUN
----------
1. Install the dependencies and spaCy model.
2. Recreate or update the expected directory structure.
3. Update all hard-coded input/output paths.
4. Ensure the required refined/unrefined spreadsheets and CoNLL files exist.
5. Run the notebook from top to bottom.
6. Check the token-count and matched-length QC outputs.
7. Use the prepared CSV files as inputs to biodistilBERT.ipynb and
   distilBERT.ipynb.

IMPORTANT REPRODUCIBILITY NOTES
-------------------------------
- This notebook was developed against the original local Windows directory
  structure and contains many hard-coded relative paths.
- Output directories must exist before files are written.
- Several sections are exploratory/descriptive and create intermediate files;
  the final model inputs are the prepared CSV files listed above.
- Package versions are not pinned.
- No truncation is applied in this preprocessing notebook when the checked
  record token counts are below the intended model limit; tokenisation in the
  downstream transformer notebooks still uses truncation=True.
