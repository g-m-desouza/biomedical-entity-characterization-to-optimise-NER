README — biodistilBERT.ipynb
===============================

PURPOSE
-------
This Google Colab-oriented notebook trains and evaluates a biomedical
DistilBERT token-classification model for two ODAN named-entity types:
Company Name and Line of Therapy (LoT).

Base pretrained model:
    nlpie/bio-distilbert-uncased

The notebook contains both:
- a fixed-hyperparameter (no-HPO) training workflow; and
- an Optuna hyperparameter-optimisation workflow with cross-validation.

INPUT DATA
----------
At runtime the notebook prompts for paths to:
- training CSV
- validation CSV
- test CSV

The expected files are the prepared CSV datasets produced by PPA(4).ipynb.

Required columns:
- sentence num
- token
- ner_tag_ids

The "token" and "ner_tag_ids" columns are expected to contain Python-list
representations that can be parsed with ast.literal_eval().

LABELS
------
The five labels are:
- O
- B-Co
- I-Co
- B-LoT
- I-LoT

The notebook maps these to IDs 0-4 in the listed order.

ENVIRONMENT / DEPENDENCIES
--------------------------
The notebook is designed around Google Colab and includes optional Google Drive
mounting.

It explicitly installs:
    datasets optuna evaluate seqeval

It also requires:
- numpy
- pandas
- transformers
- scikit-learn
- google-colab (when run in Colab)

A GPU runtime is strongly recommended for model training and cross-validation.

Internet access is required on a clean environment to retrieve the pretrained
model/tokenizer and the seqeval metric unless they are already cached.

TOKENISATION
------------
Tokenizer:
    nlpie/bio-distilbert-uncased

Input data are treated as pre-split words using:
    is_split_into_words=True

Special tokens are assigned label -100 so that they are ignored by the loss
and metric calculations. In the current function, subword pieces inherit the
parent word label because label_all_tokens defaults to True.

METRICS
-------
The notebook uses the Hugging Face evaluate implementation of seqeval.

It calculates:
- overall precision
- overall recall
- overall F1
- overall accuracy
- Company Name precision/recall/F1/accuracy
- LoT precision/recall/F1/accuracy

Entity-specific evaluation is produced by replacing the other entity type with
O before seqeval is called.

NO-HPO TRAINING SETTINGS IN THE CURRENT NOTEBOOK
------------------------------------------------
- learning rate: 2e-5
- training batch size: 16
- evaluation batch size: 16
- epochs: 15
- weight decay: 0.01
- evaluation/logging: once per epoch

Saved training logs and model directories are manually named by run number.
The current example cells refer to run 5.

HYPERPARAMETER OPTIMISATION
---------------------------
Optimizer/search library:
- Optuna

Cross-validation:
- StratifiedKFold
- 17 folds in the current notebook

Search space in the current code:
- learning_rate: 2e-5 to 4e-5, logarithmic
- per_device_train_batch_size: 4, 8 or 16
- num_train_epochs: 4 to 15
- weight_decay: fixed at 0.01

Objective:
- mean overall F1 across the cross-validation folds

Current study call:
- 10 Optuna trials

The selected parameters are saved to:
- best_HPO_cv_ref_params.csv

The selected parameters are then used to train a final model.

MAIN OUTPUTS
------------
Examples of outputs written by the current notebook include:

No-HPO:
- base_unref_bioDistilBERT_run_5.csv
- noHPO_models/base_unref_biodistilBERT_model_run_5/
- un_noHPO_models.zip

HPO:
- cv_data/df_unref_HPO_CV_...csv
- best_HPO_cv_ref_params.csv
- train_HPO_data/unref_HPO_cv_bioDistilBERT_run_5.csv
- HPO_trained_model/unref_HPO_cv_distilBERT_model_run_5/
- unref_HPO_cv_trained_model.zip
- unref_HPO_cv_train_data.zip

Testing:
- a test-results CSV is written by the final testing section
  (the exact filename is manually configured in the notebook).

The notebook also contains sections for cleaning the staggered Trainer log
history and for loading saved models from Google Drive before testing.

HOW TO RUN
----------
1. Open in Google Colab or an equivalent Python environment with sufficient
   memory/GPU support.
2. Run the package-installation cell.
3. Mount Google Drive if needed.
4. Enter the training, validation and test CSV paths when prompted.
5. Run preprocessing/tokenisation cells.
6. Run either the no-HPO section, HPO section, or both as required.
7. Before each repeated training run, update the run number/output paths.
8. Create any referenced output directories before saving.
9. In the testing section, update the saved-model path and evaluation batch
   size to match the model being evaluated.
10. Run the test section and save the evaluation results.

IMPORTANT REPRODUCIBILITY NOTES
-------------------------------
- Output paths and run numbers are manually edited in several cells.
- Some filenames retain labels from particular experimental configurations
  (for example "unref") and should be interpreted together with the data paths
  actually supplied to the run.
- The notebook does not pin package versions or exact Colab hardware.
- For an archival rerun, record the exact input dataset, run number, selected
  Optuna parameters, package versions and runtime hardware.
- The HPO and repeated-run sections should be checked against the final
  manuscript configuration before public release because several settings are
  embedded directly in code rather than centralised in one configuration cell.
