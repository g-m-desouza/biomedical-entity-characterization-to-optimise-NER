README — distilBERT.ipynb
============================

PURPOSE
-------
This Google Colab-oriented notebook trains and evaluates a general-domain
DistilBERT token-classification model for ODAN Company Name and Line of Therapy
(LoT) named entities.

Base pretrained model:
    distilbert-base-uncased

The notebook contains:
- fixed-hyperparameter (no-HPO) training;
- Optuna hyperparameter optimisation with cross-validation;
- training-log cleaning;
- saved-model loading; and
- test-set evaluation across repeated model runs.

INPUT DATA
----------
At runtime the notebook prompts for paths to:
- training CSV
- validation CSV
- test CSV

The expected files are prepared by PPA(4).ipynb.

Required columns:
- sentence num
- token
- ner_tag_ids

The "token" and "ner_tag_ids" fields are expected to contain string
representations of Python lists and are converted with ast.literal_eval().

LABELS
------
The five labels are:
- O
- B-Co
- I-Co
- B-LoT
- I-LoT

These correspond to IDs 0-4 in that order.

ENVIRONMENT / DEPENDENCIES
--------------------------
The notebook is designed around Google Colab and can optionally mount Google
Drive.

It explicitly installs:
    datasets optuna evaluate seqeval

It also requires:
- numpy
- pandas
- transformers
- scikit-learn
- google-colab (when run in Colab)

A GPU runtime is strongly recommended.

Internet access is required in a clean environment to obtain
distilbert-base-uncased and the seqeval metric unless already cached.

TOKENISATION
------------
Tokenizer:
    distilbert-base-uncased

The input tokens are passed as pre-split words using:
    is_split_into_words=True

Special tokens receive label -100. In the current tokenisation function,
subword pieces inherit the parent label because label_all_tokens defaults to
True.

METRICS
-------
The notebook uses seqeval through Hugging Face evaluate and is structured to
return:
- overall precision/recall/F1/accuracy
- Company Name precision/recall/F1/accuracy
- LoT precision/recall/F1/accuracy

For entity-specific metrics, the other entity type is replaced with O before
evaluation.

NO-HPO TRAINING SETTINGS IN THE CURRENT NOTEBOOK
------------------------------------------------
- learning rate: 2e-5
- training batch size: 16
- evaluation batch size: 16
- epochs: 15
- weight decay: 0.01
- evaluation/logging: once per epoch

The output filenames/run numbers are edited manually. The current example cells
use run 5 in several places.

HYPERPARAMETER OPTIMISATION
---------------------------
Library:
- Optuna

Cross-validation:
- StratifiedKFold
- 17 folds in the current notebook

Search space in the current code:
- learning_rate: 2e-5 to 4e-5, logarithmic
- per_device_train_batch_size: 4, 8 or 16
- num_train_epochs: 4 to 15
- weight_decay: fixed at 0.01

Objective:
- mean overall F1 across folds

Current study call in this notebook:
- 5 Optuna trials

The selected parameter table is saved as:
- best_HPO_cv_ref_params.csv

MAIN OUTPUTS
------------
Examples in the current notebook include:

No-HPO:
- ref_base_modedata_distilBERT_train_data/base_ref_DistilBERT_ref_run_5.csv
- ref_base_distilBERT_train_model/base_distilBERT_model_run_5/
- zipped training/model directories

HPO:
- cv_data/df_ref_HPO_CV_...csv
- best_HPO_cv_ref_params.csv
- HPO training-log CSV files
- ref_HPO_cv_distilBERT_model/ref_HPO_cv_distilBERT_model_run_5/
- zipped HPO model/training-data directories

Testing:
- ref_base_results.csv in the current example configuration

The notebook also includes code to clean the interleaved/staggered Hugging Face
Trainer log history.

HOW TO RUN
----------
1. Open in Google Colab or a comparable Python environment.
2. Run the dependency-installation cell.
3. Mount Google Drive if required.
4. Enter paths to the prepared train/validation/test CSV files.
5. Run the preprocessing and tokenisation cells.
6. Run the no-HPO and/or HPO workflow required for the experiment.
7. Update run-specific save names before each repeated run.
8. Ensure referenced output folders exist.
9. Update the saved-model path before the test loop.
10. Run test evaluation and save the result table.

IMPORTANT REPRODUCIBILITY NOTES
-------------------------------
- Several filenames and paths are manually changed between experimental
  configurations and should be checked before every run.
- The notebook does not pin dependency versions or exact Colab hardware.
- The current HPO study call uses 5 trials; this value is embedded in the code
  and should be checked against the final experimental specification before
  public release.
- The HPO/repeated-run settings are not centralised in a single configuration
  object, so an archival package should retain the exact notebook version used
  for the reported results.
- Before publication/release, independently verify the entity-specific metric
  masking code and the HPO stratification-label construction against the final
  analysis specification.
