# DATASET DESCRIPTION AND TERMINOLOGY

## Overview

This directory contains the data used for the named entity recognition (NER) experiments described in the accompanying manuscript. The corpus consists of Oncology Drug Approval News (ODAN) approval records and supports the identification of two entity types: Company Name and Line of Therapy (LoT).

The released files retain some legacy terminology used during the original development and analysis. These legacy names have been preserved so that filenames, analysis notebooks and code references remain consistent with the original experimental workflow. The terminology used in the manuscript should be regarded as the current terminology.

## Terminology mapping

The following mapping should be used when interpreting filenames and code:

Legacy term        Manuscript term

---

unrefined          Initial annotation
refined            Protocol-standardized annotation
refined_add        Protocol-standardized plus additional training data
moredata           Additional protocol-standardized training data

Therefore, for example:

* `modelready_unrefined_train.csv` contains the initial-annotation training data.
* `modelready_refined_train.csv` contains the protocol-standardized baseline training data.
* `refined_taggedtrain_moredata.conll` contains the additional protocol-standardized training records.
* `modelready_refined_add_train.csv` contains the expanded protocol-standardized training partition after the additional training records were combined with the baseline training partition.

The terms `unrefined` and `refined` in filenames and code are historical implementation labels only. They correspond to the annotation conditions described above and should not be interpreted as additional experimental conditions or as quantitative assessments of data quality.

## Dataset conditions

The baseline corpus contains 558 approval records. Two versions of this baseline corpus were used:

1. Initial annotation
   The records were annotated before implementation of the formalized annotation protocol.

2. Protocol-standardized annotation
   The records were annotated using the standardized annotation rules described in the manuscript, including rules governing entity relevance, span boundaries, repeated mentions and minimum-span annotation.

Each baseline condition contains:

* Training: 356 records
* Validation: 90 records
* Test: 112 records
* Total: 558 records

The initial-annotation and protocol-standardized corpora were independently randomly partitioned. Consequently, corresponding training, validation and test partitions should not be assumed to contain exactly the same approval records.

An additional 95 protocol-standardized records were subsequently introduced for the training-data quantity experiment. These records were added only to the protocol-standardized training partition. The validation and test partitions were unchanged.

The resulting expanded condition contains:

* Training: 451 records
* Validation: 90 records
* Test: 112 records
* Total: 653 records

## File formats

Three principal representations of the data are provided.

1. Excel files (.xlsx)

These contain the approval-record-level source data and annotations used during dataset development. Fields include the approval text and associated metadata and annotation information.

The principal entity types investigated in the accompanying study are Company Name and Line of Therapy (LoT). Other fields retained in the spreadsheets provide source, drug or clinical context but were not additional target entity classes in the reported NER experiments.

2. CoNLL files (.conll)

These contain the token-level BIO annotations used to prepare the NER datasets.

The entity labels are:

* O: outside an annotated entity
* B-Co: beginning of a Company Name entity
* I-Co: continuation of a Company Name entity
* B-LoT: beginning of a Line of Therapy entity
* I-LoT: continuation of a Line of Therapy entity

The CoNLL files represent annotation-level tokens before transformer WordPiece tokenization.

3. Model-ready CSV files (`modelready_*.csv`)

These are the processed datasets used as inputs to the model-training notebooks. Each row represents an ODAN approval record and contains list-valued token and NER-label sequences.

The principal columns are:

* `sentence num`: legacy sequence/record identifier
* `token`: list of tokens for the approval record
* `ner_tag`: corresponding BIO labels
* `ner_tag_ids`: numerical representation of the BIO labels
* `token_len`: number of tokens
* `ner_tag_len`: number of BIO labels
* `ner_tag_ids_len`: number of numerical labels
* `matched`: quality-control field indicating whether the sequence lengths match

The numerical label mapping used by the modelling pipeline is:

* 0 = O
* 1 = B-Co
* 2 = I-Co
* 3 = B-LoT
* 4 = I-LoT

## Directory structure

`initial annotation/`

Contains the initial-annotation baseline training, validation and test data. Files containing `unrefined` in their names belong to this condition.

`protocol standardized/`

Contains the protocol-standardized baseline training, validation and test data and the additional protocol-standardized training data. Files containing `refined` in their names belong to this condition.

Within this directory, `refined_taggedtrain_moredata.conll` represents the additional training subset, whereas `modelready_refined_add_train.csv` represents the complete expanded training partition of 451 records.

## Reproducibility note

Legacy filenames and variable names were intentionally retained in the released material because they are referenced directly by the analysis and modelling notebooks. Renaming these files or variables would alter the original computational workflow without changing the underlying experimental conditions.

Readers should therefore use the terminology mapping above when relating the released code and data to the conditions described in the manuscript.
